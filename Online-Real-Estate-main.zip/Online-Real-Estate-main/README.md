# Online Real Estate
The project online real estate system for propose buying and selling properties in user-friendly format.
Users can search and browse for property in this application.
This website deals with selling and buying the houses, lands, commercial properties.
This system will provide facility to view the property by admin and user.
User will able to upload the property information to the site and able to manage it.
This system will provide facility to user to feedback to the site.

STAKEHOLDERS:
Admin
Seller User
Buyer User

MODULES:
Registration Module
Login module
Admin module
User module
Upload property
Delete Property
Search Properties
Profile Module
Logout
Rating/Feedback
